package com.example.romanos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RomanosApplicationTests {

    @Test
    void contextLoads() {
    }

}
